
let novoNome = []

function adicionarAmigo() {

    let nome = document.querySelector('input').value
    console.log(nome);

    if (nome == "") {
        alert("Por favor,insira um nome.");
        return;
    }
    else {
        novoNome.push(nome);

        nome = document.querySelector('input');
        nome.value = '';
    }
}

function atualizarAmigo() {
    let lista = document.querySelector('ul').value;
    lista.innerHTML = "";

    for (let i = 0; i < amigos.length; i++) {
        let lista = document.createElement("li");
        lista.textContent = novoNome[i];
        lista.push(li);
    }
}

function sortearAmigo() {

    if (novoNome.length == 0) {
        alert("Adicione um nome antes de sortear.");
        return;
    }

    let sorteio = Math.floor(Math.random() * novoNome.length);
    let nomeSorteado = novoNome[sorteio];

    let resultado = document.querySelector("#resultado")
    resultado.innerHTML = `<li> O amigo secreto sorteado é: ${nomeSorteado}</li>`

}

